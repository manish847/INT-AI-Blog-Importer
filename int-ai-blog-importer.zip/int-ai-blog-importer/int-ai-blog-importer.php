<?php
/**
 * Plugin Name: INT AI Blog Importer
 * Description: Generates blog posts using AI and creates them in WordPress.
 * Version: 1.0
 * Author: Manish pathak
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

require_once plugin_dir_path(__FILE__) . 'includes/int-ai-api-handler.php';

// Add Admin Menu
add_action('admin_menu', function () {
    add_menu_page(
        'INT AI Blog Importer',
        'INT AI Blog Importer',
        'manage_options',
        'int-ai-blog-importer',
        'int_ai_blog_importer_admin_page',
        'dashicons-edit',
        20
    );

    add_submenu_page(
        'int-ai-blog-importer',
        'Settings',
        'Settings',
        'manage_options',
        'int-ai-blog-importer-settings',
        'int_ai_blog_importer_settings_page'
    );
});

/* =========================
   Settings Page
========================= */
function int_ai_blog_importer_settings_page() {

    if (isset($_POST['save_api_key'])) {
        update_option(
            'int_ai_blog_importer_api_key',
            sanitize_text_field($_POST['api_key'])
        );
        echo '<div class="updated"><p>API Key saved successfully.</p></div>';
    }

    $api_key = get_option('int_ai_blog_importer_api_key');
    ?>

    <div class="wrap">
        <h1>INT AI Blog Importer Settings</h1>

        <form method="post">
            <label><strong>OpenAI API Key:</strong></label><br><br>
            <input type="text"
                   name="api_key"
                   value="<?php echo esc_attr($api_key); ?>"
                   style="width:400px;"
                   required>
            <br><br>
            <input type="submit"
                   name="save_api_key"
                   class="button button-primary"
                   value="Save API Key">
        </form>
    </div>

<?php
}

/* =========================
   Generator Page
========================= */
function int_ai_blog_importer_admin_page() {

    $api_key = get_option('int_ai_blog_importer_api_key');

    if (empty($api_key)) {
        echo '<div class="error"><p><strong>Error:</strong> Please configure your API key in Settings first.</p></div>';
        return;
    }
?>

<div class="wrap">
    <h1>INT AI Blog Generator</h1>

    <form method="post">
        <label><strong>Enter Topic:</strong></label><br><br>

        <input type="text"
               name="ai_topic"
               required
               style="width:400px;">

        <br><br>

        <select name="post_status">
            <option value="draft">Save as Draft</option>
            <option value="publish">Publish</option>
        </select>

        <br><br>

        <input type="submit"
               name="generate_post"
               class="button button-primary"
               value="Generate Post">
    </form>
</div>

<?php

    if (isset($_POST['generate_post'])) {

        $topic  = sanitize_text_field($_POST['ai_topic']);
        $status = sanitize_text_field($_POST['post_status']);

        $ai_response = ai_generate_blog($topic);

        if (!$ai_response || isset($ai_response['error'])) {
            echo '<div class="error"><p><strong>Error:</strong> '
                 . esc_html($ai_response['error'])
                 . '</p></div>';
            return;
        }

        $post_id = wp_insert_post([
            'post_title'   => $ai_response['title'],
            'post_content' => $ai_response['content'],
            'post_status'  => $status,
            'post_author'  => get_current_user_id(),
        ]);

        if (!is_wp_error($post_id)) {
            wp_set_post_tags($post_id, $ai_response['tags']);
            echo '<div class="updated"><p>Post created successfully!</p></div>';
        } else {
            echo '<div class="error"><p>Error creating post.</p></div>';
        }
    }
}