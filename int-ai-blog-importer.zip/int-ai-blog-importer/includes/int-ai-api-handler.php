<?php

function ai_generate_blog($topic) {

    $api_key = get_option('int_ai_blog_importer_api_key');

    if (empty($api_key)) {
        return ['error' => 'API key not configured.'];
    }

    $prompt = "Generate a blog post for the topic: $topic.
Return strictly in this format:

Title:
Content:
Tags: (comma separated)";

    $response = wp_remote_post(
        'https://api.openai.com/v1/chat/completions',
        [
            'headers' => [
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $api_key,
            ],
            'body' => json_encode([
                'model' => 'gpt-3.5-turbo',
                'messages' => [
                    [
                        'role' => 'user',
                        'content' => $prompt
                    ]
                ],
                'temperature' => 0.7
            ]),
            'timeout' => 60
        ]
    );

    if (is_wp_error($response)) {
        return ['error' => 'API request failed.'];
    }

    $body = json_decode(
        wp_remote_retrieve_body($response),
        true
    );

    if (!isset($body['choices'][0]['message']['content'])) {
        return ['error' => 'Invalid AI response.'];
    }

    $text = $body['choices'][0]['message']['content'];

    preg_match('/Title:(.*)/', $text, $title);
    preg_match('/Content:(.*)Tags:/s', $text, $content);
    preg_match('/Tags:(.*)/', $text, $tags);

    return [
        'title'   => trim($title[1] ?? 'AI Generated Post'),
        'content' => trim($content[1] ?? ''),
        'tags'    => trim($tags[1] ?? '')
    ];
}